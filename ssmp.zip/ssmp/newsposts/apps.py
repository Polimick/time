from django.apps import AppConfig


class NewspostsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newsposts'
    verbose_name = 'Новостной портал SSMP'
